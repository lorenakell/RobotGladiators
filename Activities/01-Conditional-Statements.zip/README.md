# Conditional Statements

## Instructions

* Create a site (from scratch) that asks users if they eat steak.

* If they respond with "yes", alert the following to the page: "Here’s a cheese burger!"

* If they respond with "no", alert the following to the page: "Here’s an Impossible burger!"

