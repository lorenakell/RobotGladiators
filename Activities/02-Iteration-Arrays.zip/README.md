# Iteration, Arrays

## Instructions

* Refactor the code to use a `for` loop to log the name of each animal in the `zooAnimals` array rather than logging each item individually.


## Bonus

What is DRY?

