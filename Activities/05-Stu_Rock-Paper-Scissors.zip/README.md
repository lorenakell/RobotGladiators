# Rock-Paper-Scissors

## Instructions

* From scratch, create a simple Rock-Paper-Scissors game in which one player plays against a computer opponent. 

* Use `prompt()` to get user play.

* Use `alert()` to state whether the user or computer wins.

### Rules for RPS

* Rock: wins against scissors, loses to paper, and ties against itself.

* Paper: wins against rock, loses to scissors, and ties against itself.

* Scissors: wins against paper, loses to rock, and ties against itself.
