# Iteration, Random

## Instructions

* From scratch, create a simple 'site' that logs 10 random numbers using a `for` loop and `Math.random()`


## Hint(s)

* `Math.random()` returns a decimal (or _floating point_) number. How will you convert it to a whole number?
