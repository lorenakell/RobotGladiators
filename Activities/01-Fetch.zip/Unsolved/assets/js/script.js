// Write a fetch request to the Giphy API
// Then log the response in the console
