# Functions

## Instructions

* Create a function, `adder()`, that accepts three arguments and returns their sum.

* Create a function, `muliplier()`, that accepts three arguments and returns their product. 

* Create a function, `isString()`, that accepts three arguments and checks if the type of all three is string.

* Create a function, `vowelCheker()`, that accepts one argument, a string, and checks if the first letter of the string is a vowel. 


## Hint(s) 

* How do check the _type of_ a value?

* How do you check the _character at_ a given position in a string?
